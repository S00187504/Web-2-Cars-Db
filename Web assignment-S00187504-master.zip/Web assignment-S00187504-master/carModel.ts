export interface carModel {
    carID: number,
    carMake: string,
    carModel: string,
    fuelType: string,
    carYear: number,
    carCounty: string
}