export interface User {

    userID: string;
    authID?: string;
    name?: string;
    permissionLevel?: string;
    appToken?: string;
    email?: string;
}


